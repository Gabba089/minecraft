import { world } from "@minecraft/server";

world.events.tick.subscribe(() => {
    for (const player of world.getPlayers()) {
        // Controlla se il giocatore ha l'amuleto
        if (player.getComponent("inventory").container.contains("speed_amulet")) {
            player.runCommand("effect @s speed 1 2 true");
        }
    }
});
