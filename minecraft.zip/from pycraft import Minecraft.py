from pycraft import Minecraft
from time import sleep

# Connessione al gioco
mc = Minecraft.create()

# Funzione per cercare e raccogliere legno
def collect_wood():
    while True:
        # Trova i blocchi vicini
        nearby_blocks = mc.getBlocks(-5, -5, -5, 5, 5, 5)
        for block in nearby_blocks:
            if block.id == 17:  # ID del blocco legno
                mc.setBlock(block.x, block.y, block.z, 0)  # Rimuove il legno
                mc.postToChat("Legno raccolto!")
        sleep(1)

collect_wood()
